package com.mayank.gautam99.mynotes.Room;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class NoteViewModal extends AndroidViewModel {
    NoteRepository noteRepository;
    LiveData<List<Note>> allNote;

    public NoteViewModal(Application application) {
        super(application);
        noteRepository = new NoteRepository(application);
        allNote = noteRepository.getAllNote();
    }

    public LiveData<List<Note>> getAllNote(){
        return allNote;
    }

    public void delete(Note note){
        noteRepository.delete(note);
    }

    public void update(Note note){
        noteRepository.update(note);
    }

    public void insert(Note note){
        noteRepository.insert(note);
    }

   public void deleteAll(){
        noteRepository.deleteAll();
    }
}
