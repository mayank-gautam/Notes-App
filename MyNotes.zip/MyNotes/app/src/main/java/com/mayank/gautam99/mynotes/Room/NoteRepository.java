package com.mayank.gautam99.mynotes.Room;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

public class NoteRepository {
    private NoteDao noteDao;
    private LiveData<List<Note>> allNote;

    NoteRepository(Application application){
        NoteDatabase noteDatabase = NoteDatabase.getInstance(application);
        noteDao = noteDatabase.noteDao();
        allNote = noteDao.getAllNote();
    }

    public void insert(Note note){
        NoteDatabase.databaseWriteExecutor.execute(()->{
            noteDao.insert(note);
        });
    }

    public void delete(Note note){
        NoteDatabase.databaseWriteExecutor.execute(()->{
            noteDao.delete(note);
        });
    }

    public void update(Note note){
        NoteDatabase.databaseWriteExecutor.execute(()->{
            noteDao.update(note);
        });
    }

    public void deleteAll(){
        NoteDatabase.databaseWriteExecutor.execute(()->{
            noteDao.deleteAll();
        });
    }

    LiveData<List<Note>> getAllNote(){
        return noteDao.getAllNote();
    }

}
